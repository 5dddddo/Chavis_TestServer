package com.example.final_t4ir;

import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        ImageButton settingBtn = (ImageButton) findViewById(R.id.settingBtn);
        ImageButton monitorBtn = (ImageButton) findViewById(R.id.monitorBtn);

        final Intent i = getIntent();
        final String userId = i.getExtras().getString("userId");

        monitorBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), userId, Toast.LENGTH_SHORT).show();

            }
        });
        settingBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ComponentName cname = new ComponentName("com.example.final_t4ir", "com.example.final_t4ir.SettingActivity");
                i.setComponent(cname);
                i.putExtra("userId",userId);
                startActivity(i);
            }
        });

    }
}
