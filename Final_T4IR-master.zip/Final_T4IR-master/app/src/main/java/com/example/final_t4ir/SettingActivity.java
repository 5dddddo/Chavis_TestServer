package com.example.final_t4ir;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.ToggleButton;

import androidx.appcompat.app.AppCompatActivity;

public class SettingActivity extends AppCompatActivity {
    private TextView IdTv;
    private EditText nameEt;
    private TextView nameTv;
    private ToggleButton cnameBtn;
    private EditText telEt;
    private TextView telTv;
    private ToggleButton ctelBtn;
    private Button cancelBtn;
    private String name;
    private String tel;

    //private TextView ;
//private TextView ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
        IdTv = (TextView) findViewById(R.id.IdTv);
        nameEt = (EditText) findViewById(R.id.nameEt);
        nameTv = (TextView) findViewById(R.id.nameTv);
        cnameBtn = (ToggleButton) findViewById(R.id.cnameBtn);
        telEt = (EditText) findViewById(R.id.telEt);
        telTv = (TextView) findViewById(R.id.telTv);
        ctelBtn = (ToggleButton) findViewById(R.id.ctelBtn);
        cancelBtn = (Button) findViewById(R.id.cancelBtn);

        Intent i = getIntent();
        final String userId = (String) i.getExtras().get("userId");
        name = "오은애";
        tel = "01056113427";
        IdTv.setText(userId);
        nameTv.setText(name);

        cnameBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (cnameBtn.isChecked()) {
                    nameTv.setVisibility(View.GONE);
                    nameEt.setVisibility(View.VISIBLE);
                } else {
                    if(nameEt.getText().length() != 0)
                        name = nameEt.getText().toString();
                    nameTv.setText(name);
                    nameTv.setVisibility(View.VISIBLE);
                    nameEt.setVisibility(View.GONE);

                }
            }
        });
        ctelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ctelBtn.isChecked()) {
                    telTv.setVisibility(View.GONE);
                    telEt.setVisibility(View.VISIBLE);
                } else {
                    if(telEt.getText().length() != 0)
                        tel = telEt.getText().toString();
                    telTv.setText(tel);
                    telTv.setVisibility(View.VISIBLE);
                    telEt.setVisibility(View.GONE);
                }
            }
        });

        cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent backIntent = new Intent(getApplicationContext(), HomeActivity.class);
                backIntent.putExtra("userId", userId);
                startActivity(backIntent);
            }
        });
    }
}
